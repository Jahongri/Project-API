const createdCompnay = (person) => {

    const { name, brewery_type, street, address_2, city, state, country, postal_code, phone, website_url, latitude , longitude } = person;

    const temple = `
    <div class="accordion accordion-flush" id="accordionFlushExample">
    <div class="accordion-item">
      <h2 class="accordion-header" id="flush-headingOne">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseOne" aria-expanded="false" aria-controls="flush-collapseOne">
          About Company
        </button>
      </h2>
      <div id="flush-collapseOne" class="accordion-collapse collapse" aria-labelledby="flush-headingOne" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">
        <p> Name :" ${name}  </p>
        <p> Brewery_type :" ${brewery_type}  </p>
        <p> Latitude :" ${latitude}  </p>
        <p> Longitude :" ${longitude}  </p>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="flush-headingTwo">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseTwo" aria-expanded="false" aria-controls="flush-collapseTwo">
          Location Companys'
        </button>
      </h2>
      <div id="flush-collapseTwo" class="accordion-collapse collapse" aria-labelledby="flush-headingTwo" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">
            <p> "Address :" ${address_2} </p>
            <p> "State :" ${state} </p>
            <p> "City :" ${city} </p>
            <p> "Street :" ${street} </p>
            <p> "Country :" ${country} </p>
        </div>
      </div>
    </div>
    <div class="accordion-item">
      <h2 class="accordion-header" id="flush-headingThree">
        <button class="accordion-button collapsed" type="button" data-bs-toggle="collapse" data-bs-target="#flush-collapseThree" aria-expanded="false" aria-controls="flush-collapseThree">
          Call Center 
        </button>
      </h2>
      <div id="flush-collapseThree" class="accordion-collapse collapse" aria-labelledby="flush-headingThree" data-bs-parent="#accordionFlushExample">
        <div class="accordion-body">
        <p> "Phone :" ${phone} </p>
        <p> "Postal_code :" ${postal_code} </p>
        <p> "Website :" ${website_url} </p>
        </div>
      </div>
    </div>
  </div>


    `;

    document.querySelector("#accordionFlushExample").innerHTML +=temple;
};


fetch("https://api.openbrewerydb.org/breweries/search?query=dog")
.then((res) => res.json())
.then((data) => data.slice(0,2).forEach(createdCompnay));